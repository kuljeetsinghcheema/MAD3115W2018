//
//  loginViewController.swift
//  regisForm
//
//  Created by Kuljeet Singh on 2018-02-22.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var uname: UITextField!
    @IBOutlet weak var pwrd: UITextField!
    @IBAction func login(_ sender: UIButton) {
        let infoAlert = UIAlertController(title: "Verify", message: "allData" , preferredStyle: .alert)
        
        //infoAlert.addAction(UIAlertAction(title: "confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        self.present(infoAlert,animated: true)
    }
    
    @IBAction func regis(_ sender: UIButton) {
        let regSB: UIStoryboard = UIStoryboard(name: "main", bundle: nil)
        let regVC = regSB.instantiateViewController(withIdentifier: "regisViewController")
       
        navigationController?.pushViewController(regVC, animated: true)
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

