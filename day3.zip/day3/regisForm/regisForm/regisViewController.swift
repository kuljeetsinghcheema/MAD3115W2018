//
//  regisViewController.swift
//  regisForm
//
//  Created by Kuljeet Singh on 2018-02-22.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import UIKit

class regisViewController: UIViewController , UIPickerViewDelegate, UIPickerViewDataSource{
    func numberOfComponents(in pickerView: UIPickerView) -> Int {
        return 1
    }
    
    
    
    func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component:Int) -> Int{
        return self.cityList.count
    }
    
    func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return self.cityList[row]
    }
 
    
    @IBOutlet weak var email: UITextField!
    @IBOutlet weak var citypicker: UIPickerView!
    @IBOutlet weak var passwrd: UITextField!
    @IBOutlet weak var postalCode: UITextField!
    @IBOutlet weak var cNumber: UITextField!
    @IBOutlet weak var date: UIDatePicker!
    @IBOutlet weak var txt: UITextField!
    var cityList: [String] = ["Vancover","Toronto"]
    var selectedCityIndex:Int = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.citypicker.delegate = self as? UIPickerViewDelegate
        self.citypicker.dataSource = self as? UIPickerViewDataSource

        // Do any additional setup after loading the view.
    }
    
    @objc private func dispalyValue(){
        self.selectedCityIndex = self.citypicker.selectedRow(inComponent: 0)
        
        let allData: String = "\(self.txt.text!) \n \(self.cNumber.text!) \n \(self.date.date) \n \(self.postalCode.text!) \n \(self.email.text!) \n \(self.cityList[selectedCityIndex])"
        
        let infoAlert = UIAlertController(title: "Verify", message: allData , preferredStyle: .alert)
        
        //infoAlert.addAction(UIAlertAction(title: "confirm", style: .default, handler: {_ in self.displayWelcomeScreen()}))
        
        infoAlert.addAction(UIAlertAction(title: "Cancel", style: .destructive, handler: nil))
        }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
