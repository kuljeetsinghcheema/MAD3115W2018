//
//  register.swift
//  regisForm
//
//  Created by Kuljeet Singh on 2018-02-22.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import UIKit

class registerViewController: NSObject {

}
