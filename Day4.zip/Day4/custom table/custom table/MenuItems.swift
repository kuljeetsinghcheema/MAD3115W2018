//
//  MenuItems.swift
//  custom table
//
//  Created by Kuljeet Singh on 2018-02-23.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import Foundation

class MenuItems{
    let names:[String] = [
    "pizza","chole","bhature","chicken","daal","roti","paraunthe","matar paneer","chomin"]
    
    let prices:[Double] = [
    22.33,33.33,22.44,22.44,22.44,58.57,67.76,36.46,85.99
    ]
        
    let specials:[Bool] = [true,false,true,false,false,false,true,true,false]
}
