//
//  webPageViewController.swift
//  custom table
//
//  Created by Kuljeet Singh on 2018-02-26.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import UIKit

class webPageViewController: UIViewController {

    @IBOutlet weak var webPage: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func loadWebPage(){
        let url = NSURL (string: "https://www.google.com")
        let requestObj = NSURL (url: url! as URL);
        webPage.loadReqest(requestObj as URLRequest)
    }
    
    func loadMannualPage()
    {
        let localFilePath = Bundle.main.url(forResource: "pizza", withExtension: <#T##String?#>, subdirectory: <#T##String?#>, localization: <#T##String?#>)
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
