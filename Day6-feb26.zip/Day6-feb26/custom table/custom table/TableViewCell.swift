//
//  TableViewCell.swift
//  custom table
//
//  Created by Kuljeet Singh on 2018-02-26.
//  Copyright © 2018 Kuljeet Singh. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    func tableView(_ tableView)
}
